"""
Лабораторная работа №1 по дисциплине ЛОИС
Выполнили студенты группы 321702 БГУИР:
    - Сергиевич Д.П.
    - Банкевич Я.Д.
    - Рублевская Е.А.
23.10.2025

Вариант 2
Реализовать прямой нечёткий логический вывод,
используя треугольную норму {xi} * {yi} и нечёткую импликацию Гогена.

Основной файл программы

Источники:
- Нечёткая логика: алгебраические основы и приложения / С.Л. Блюмин, И.А. Шуйкова
- https://github.com/AlexeyTerleev Терлеев Алексей
- Малинецкая Диана Дмитриевна 221701 (Тесты)
"""

import os
from src import operations
from src.loader import load_from_file
from src.validators import Fact, Rule


def print_table(title, table):
    output = [f"\n=== {title} ==="]
    headers = list(next(iter(table.values())).keys())
    output.append(" \t" + "\t".join(headers))
    for row in table:
        values = "\t".join(str(v) for v in table[row].values())
        output.append(f"{row}\t{values}")
    return "\n".join(output)


def process_example(file_path):
    solution = []

    if not os.path.isfile(file_path):
        return solution

    solution.append(f"\n--- Пример: {os.path.basename(file_path)} ---\n")
    solution.append("Входные данные:\n")
    with open(file_path, "r", encoding="utf-8") as f:
        solution.append(f.read())
    solution.append("\n\nПрямой нечеткий вывод:\n")

    facts, rules = load_from_file(file_path)

    rule_tables = {}
    for rule_obj in rules.values():
        first_name, second_name = [t.split('(')[0] for t in rule_obj.tail]

        if first_name not in facts or second_name not in facts:
            print(f"Ошибка: факт '{first_name if first_name not in facts else second_name}' не найден.")
            return []

        rule_tables[rule_obj.rule] = operations.matrix_impl(facts[first_name].tail, facts[second_name].tail)

    for rule_name, table in rule_tables.items():
        solution.append(print_table(rule_name, table))

    result_sets, result_heads = [], []

    for rule_name, table in rule_tables.items():
        for fact in facts.values():
            result_table = operations.built_impl_table(fact.tail, table)
            head_name = f"({rule_name})/~\\{fact.head}"
            result_heads.append(head_name)
            compressed = operations.compress(result_table)

            solution.append(print_table(head_name, result_table))
            result_sets.append("{" + ", ".join(f"({k}, {v})" for k, v in compressed.items()) + "}")

    solution.append("\nРезультат:\n")
    for i, (head, tail) in enumerate(zip(result_heads, result_sets), 1):
        solution.append(f"I{i} = {head} = {tail}\n")

    return solution


def main(data_dir):
    examples = sorted(os.listdir(data_dir))
    if not examples:
        print("Нет примеров в папке:", data_dir)
        return

    for example in examples:
        file_path = os.path.join(data_dir, example)
        result = process_example(file_path)
        print("".join(result))
        print("=" * 100 + "\n")


if __name__ == "__main__":
    main("data")
