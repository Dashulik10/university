"""
Лабораторная работа №1 по дисциплине ЛОИС
Выполнили студенты группы 321702 БГУИР:
    - Сергиевич Д.П.
    - Банкевич Я.Д.
    - Рублевская Е.А.
23.10.2025

Вариант 2
Реализовать прямой нечёткий логический вывод,
используя треугольную норму {xi} * {yi} и нечёткую импликацию Гогена.

Модуль отвечает за загрузку, обработку и преобразование входных данных для работы с системой нечёткой логики.

Источники:
- Нечёткая логика: алгебраические основы и приложения / С.Л. Блюмин, И.А. Шуйкова
- https://github.com/AlexeyTerleev Терлеев Алексей
- Малинецкая Диана Дмитриевна 221701 (Тесты)
"""

from typing import List
from src.validators import Fact, Rule

# Функция взята из https://github.com/AlexeyTerleev
def load_from_file(path):
    facts, rules = None, None

    with open(path, "r") as file:
        facts, rules = (
            tuple("".join(x.split()) for x in line.split("\n"))
            for line in file.read().split("\n\n")
        )

    facts = [Fact(fact) for fact in facts]
    rules = [Rule(rule) for rule in rules]

    return get_facts_dict(facts), get_rules_dict(rules)


def get_facts_dict(facts: List[Fact]):
    return {fact.head: fact for fact in facts}


def get_rules_dict(rules: List[Rule]):
    return {rule.rule: rule for rule in rules}
