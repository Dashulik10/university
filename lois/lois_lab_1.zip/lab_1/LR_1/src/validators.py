"""
Лабораторная работа №1 по дисциплине ЛОИС
Выполнили студенты группы 321702 БГУИР:
    - Сергиевич Д.П.
    - Банкевич Я.Д.
    - Рублевская Е.А.
23.10.2025

Вариант 2
Реализовать прямой нечёткий логический вывод,
используя треугольную норму {xi} * {yi} и нечёткую импликацию Гогена.

Валидация правил и фактов.

Источники:
- Нечёткая логика: алгебраические основы и приложения / С.Л. Блюмин, И.А. Шуйкова
- https://github.com/AlexeyTerleev Терлеев Алексей
- Малинецкая Диана Дмитриевна 221701 (Тесты)
"""

import re

# Частично код взят из https://github.com/AlexeyTerleev
class Fact:
    class InvalidFactExeption(Exception):
        def __init__(self, fact: str) -> None:
            super().__init__(f"Invalid format of fact: {fact}")

    def __init__(self, fact: str, valid_check=True) -> None:
        self.fact = fact

        if valid_check and not self.__is_valid():
            raise Fact.InvalidFactExeption(fact)

        self.head = self.__get_head()

        self.tail = self.__get_tail()

        if not self.__tail_is_valid():
            raise Fact.InvalidFactExeption(fact)

        self.tail = {pair[0]: pair[1] for pair in self.tail}

    # Наша реализация функции
    def __is_valid(self):
        pattern = re.compile(
            r'^([A-Z]\d*)\s*=\s*\{\s*'
            r'(?:<([a-z]),\s*(0(?:\.\d+)?|1(?:\.0+)?)>\s*'
            r'(?:,\s*<([a-z]),\s*(0(?:\.\d+)?|1(?:\.0+)?)>)*\s*)?'
            r'\}$'
        )
        match = pattern.match(self.fact)
        if not match:
            return False

        elements = re.findall(r'<([a-z]),', self.fact)
        if len(elements) != len(set(elements)):
            return False

        return True

    def __get_head(self):
        head_tail_pattern = r"^(.+)={(.*)}$"
        fact_name =re.match(head_tail_pattern, self.fact).group(1)
        return fact_name

    # Наша реализация функции
    def __get_tail(self):
        head_tail_pattern = r"^(.+)={(.*)}$"
        pairs_str = re.match(head_tail_pattern, self.fact).group(2).strip()
        if not pairs_str:
            return tuple()
        elements = re.findall(r'<([a-z]),\s*([0-1](?:\.\d+)?)>', pairs_str)
        tail = tuple((symbol, float(value)) for symbol, value in elements)
        return tail

    def __tail_is_valid(self):
        return len(set(map(lambda x: x[0], self.tail))) == len(list(map(lambda x: x[0], self.tail)))


class Rule:
    class InvalidRuleExeption(Exception):
        def __init__(self, rule: str) -> None:
            super().__init__(f"Invalid format of rule: {rule}")

    def __init__(self, rule: str) -> None:
        self.rule = rule

        if not self.__is_valid():
            raise Rule.InvalidRuleExeption(rule)

        self.tail = self.__get_tail()

    # Наша реализация функции
    def __is_valid(self):
        pattern = re.compile(r'^([A-Z]\d*)\(([a-z])\)\s*~>\s*([A-Z]\d*)\(([a-z])\)$')
        m = pattern.match(self.rule)
        return bool(m and m.group(2) != m.group(4))

    def __get_tail(self):
        return tuple(self.rule.split("~>"))
