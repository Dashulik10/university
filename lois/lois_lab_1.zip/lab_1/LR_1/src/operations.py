"""
Лабораторная работа №1 по дисциплине ЛОИС
Выполнили студенты группы 321702 БГУИР:
    - Сергиевич Д.П.
    - Банкевич Я.Д.
    - Рублевская Е.А.
23.10.2025

Вариант 2
Реализовать прямой нечёткий логический вывод,
используя треугольную норму {xi} * {yi} и нечёткую импликацию Гогена.

Реализация набора функций для выполнения операций в системе нечёткой логики
с использованием импликации Гогена, T-нормы и обработки матриц.
    Эти функции используются для выполнения прямого нечёткого вывода:
    - расчёта импликации между нечёткими множествами,
    - построения таблиц логического вывода,
    - сжатия результатов.

Источники:
- Нечёткая логика: алгебраические основы и приложения / С.Л. Блюмин, И.А. Шуйкова
- https://github.com/AlexeyTerleev Терлеев Алексей
- Малинецкая Диана Дмитриевна 221701 (Тесты)
"""

def gogen_impl(v1, v2):
    return 1 if v1 == 0 else min(1, v2 / v1)

# Функция взята из https://github.com/AlexeyTerleev
def matrix_impl(set1, set2):
    return {i: {j: gogen_impl(set1[i], set2[j]) for j in set2} for i in set1}


def t_norm(v1, v2):
    return v1 * v2

# Функция взята из https://github.com/AlexeyTerleev
def built_impl_table(set1, relation):
    if set(set1.keys()) != set(relation.keys()):
        raise ValueError(f"{set(set1.keys())} != {set(relation.keys())}")

    return {
        i: {j: t_norm(set1[i], relation[i][j]) for j in relation[i]}
        for i in relation
    }


def compress(impl_table):
    row_keys = list(impl_table.keys())
    col_keys = list(impl_table[row_keys[0]].keys())
    result = {}

    for col_key in col_keys:
        column_values = []
        for row_key in row_keys:
            value = impl_table[row_key][col_key]
            column_values.append(value)
        result[col_key] = max(column_values)

    return result
